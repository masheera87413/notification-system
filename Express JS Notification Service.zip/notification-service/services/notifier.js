require('dotenv').config();
const axios = require('axios');
const twilio = require('twilio');
const admin = require('firebase-admin');

const client = twilio(process.env.TWILIO_SID, process.env.TWILIO_AUTH);

if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL
    })
  });
}

module.exports = {
  send: async (notification) => {
    const { type, message, userId } = notification;

    switch (type) {
      case 'email':
        await axios.post('https://api.zeptomail.com/v1.1/email', {
          bounce_address: process.env.ZEPTO_FROM,
          from: {
            address: process.env.ZEPTO_FROM,
            name: 'Notifier Service'
          },
          to: [{ email_address: { address: userId } }],
          subject: 'New Notification',
          htmlbody: `<p>${message}</p>`
        }, {
          headers: {
            'Authorization': `Zoho-enczapikey ${process.env.ZEPTO_API_KEY}`,
            'Content-Type': 'application/json'
          }
        });
        break;

      case 'sms':
        await client.messages.create({
          body: message,
          from: process.env.TWILIO_PHONE,
          to: userId
        });
        break;

      case 'in-app':
        await admin.messaging().send({
          token: userId,
          notification: {
            title: 'Notification',
            body: message
          }
        });
        break;

      default:
        throw new Error('Unsupported notification type');
    }

    return true;
  }
};