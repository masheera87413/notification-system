const express = require('express');
const { v4: uuidv4 } = require('uuid');
const notificationQueue = require('../services/queue');

const router = express.Router();
const userNotifications = {};

router.post('/', async (req, res) => {
  const { userId, type, message } = req.body;

  if (!userId || !type || !message) {
    return res.status(400).json({ error: 'userId, type, and message are required' });
  }

  const id = uuidv4();
  const notification = { id, userId, type, message, status: 'queued', timestamp: new Date() };

  if (!userNotifications[userId]) {
    userNotifications[userId] = [];
  }
  userNotifications[userId].push(notification);

  await notificationQueue.add('sendNotification', notification, {
    attempts: 3,
    backoff: 5000
  });

  res.status(202).json({ message: 'Notification queued', id });
});

router.get('/users/:id/notifications', (req, res) => {
  const { id } = req.params;
  res.json(userNotifications[id] || []);
});

module.exports = router;