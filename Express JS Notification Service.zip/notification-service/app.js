const express = require('express');
const bodyParser = require('body-parser');
const notificationRoutes = require('./routes/notifications');
require('dotenv').config();

const app = express();
app.use(bodyParser.json());

app.use('/notifications', notificationRoutes);
app.get('/users/:id/notifications', notificationRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Notification Service running on port ${PORT}`);
});