const notificationQueue = require('../services/queue');
const notifier = require('../services/notifier');

notificationQueue.process('sendNotification', async (job, done) => {
  try {
    await notifier.send(job.data);
    done();
  } catch (error) {
    console.error(`Error sending notification: ${error.message}`);
    done(new Error('Retry notification'));
  }
});